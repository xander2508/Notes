Amazon Keyspaces is a scalable, highly available, and managed Apache Cassandra compatible database service.

Apache Cassandra is a popular option for high-scale applications that need top-tier performance.

Amazon Keyspaces is a good option for high-volume applications with straightforward access patterns. 

With Amazon Keyspaces, you can run your Cassandra workloads on AWS using the same Cassandra Query Language (CQL) code, Apache 2.0 licensed drivers, and tools that you use today.