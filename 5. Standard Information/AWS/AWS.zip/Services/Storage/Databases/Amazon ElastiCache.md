ElastiCache is a fully managed, in-memory caching solution. It provides support for two open-source, in-memory cache engines: Redis and Memcached. 

You aren’t responsible for instance failovers, backups and restores, or software upgrades.