
CloudTrail records requests made, services used, actions performed, parameters for the action and response elements.