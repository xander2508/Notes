
Supports Identity Providers giving users federated roles.